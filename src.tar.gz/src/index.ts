// W2M - Entry point
// Este archivo será implementado más adelante

console.log('W2M - WhatsApp to Markdown');
console.log('Starting...');

